// ==UserScript==
// @name         "Following" Page as Default for Threads
// @namespace    http://tampermonkey.net/
// @version      2023-12-29
// @description  Set "Following" as the default timeline for threads.net
// @author       Scalar42
// @match        https://www.threads.net/
// @icon         https://static.cdninstagram.com/rsrc.php/v3/ye/r/eJ0zF04lTq5.png
// @grant        none
// @license      MIT
// @downloadURL https://update.greasyfork.org/scripts/483377/%22Following%22%20Page%20as%20Default%20for%20Threads.user.js
// @updateURL https://update.greasyfork.org/scripts/483377/%22Following%22%20Page%20as%20Default%20for%20Threads.meta.js
// ==/UserScript==

(function () {
    'use strict';

    window.onload = function () {
        const button = document.querySelector('.xixxii4 [role="button"] [dir="auto"]');
        if (button && button.innerText !== 'Following') {
            button.click();
        }
    }
})();
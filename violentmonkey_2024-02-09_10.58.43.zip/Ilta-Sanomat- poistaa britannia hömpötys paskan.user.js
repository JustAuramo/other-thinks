// ==UserScript==
// @name     Ilta-Sanomat: poistaa britannia hömpötys paskan
// @description poistaa britannia hömpötys paskan.
// @namespace https://github.com/justauramo
// @match *://*.is.fi/* 
// @version  1
// ==/UserScript==
//


// List of all king, death, words that we don't like
// Keep these lowercase
const CORONA_WORDS = [
    'kuninkaalliset'
  
];

function removeArticle(article) {
    article.remove();
}

function findArticles() {
    const articles = Array.from(document.querySelectorAll("article"));

    articles.forEach(article => {
        const textContent = article.textContent.toLowerCase();
        if (CORONA_WORDS.some(word => textContent.includes(word))) {
            removeArticle(article);
        }
    });
}

window.addEventListener('load', () => {
    // Find some on initial page load, as our event listener may not wake up yet
    findArticles();

    // Listen for any DOM inserts under main (to combat virtual scrolling)
    document.querySelector('main').addEventListener('DOMNodeInserted', () => {
        findArticles();
    });
}, false);
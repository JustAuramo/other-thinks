// ==UserScript==
// @name         OP.G Update/Match-Detail Button Fix
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  When using Adblock to block trackers (Facebook) the Websites breaks and the Update and Match-Details button no longer work, this userscript fixes that issue.
// @author       You
// @match        https://pubg.op.gg/*
// @icon         https://parsefiles.back4app.com/JPaQcFfEEQ1ePBxbf6wvzkPMEqKYHhPYv8boI1Rc/27c5c529e1f12ce9657db1bcbe23a62a_ef2rjiuIgo.png
// @grant        none
// ==/UserScript==

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

(async function() {
    'use strict';

    while (true){
        if (window.hasOwnProperty('$')
            && $.OP !== undefined
            && $.OP.GG !== undefined
            && $.OP.GG.tracker !== undefined
            && $.OP.GG.tracker.combine !== undefined)
        {
            $.OP.GG.tracker.combine.sendEvent = function(type, location, action, eventParams) {
                //console.log("Fixed :)");
                return true;
            };
            break;
        }
        await sleep(1);
    }
})();